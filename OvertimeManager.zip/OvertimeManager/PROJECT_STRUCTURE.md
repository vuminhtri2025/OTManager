# Quản lý tăng ca – Sơ đồ dự án

Ứng dụng Android (Kotlin + Jetpack Compose, Material 3). minSdk 26, targetSdk 34.

```
OvertimeManager/
├── .github/workflows/build.yml      # GitHub Actions: build APK debug
├── .gitignore
├── settings.gradle.kts
├── build.gradle.kts                 # plugin AGP 8.5.2, Kotlin 1.9.24
├── gradle.properties
└── app/
    ├── build.gradle.kts             # Compose, Material3, SDK, dependencies
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/
        │   ├── values/              # strings, colors, themes (sáng)
        │   ├── values-night/        # colors, themes (tối)
        │   ├── drawable/ic_launcher_foreground.xml
        │   └── mipmap-anydpi-v26/   # icon ứng dụng (adaptive)
        └── java/com/otmanager/app/
            ├── MainActivity.kt          # Thanh điều hướng 4 tab
            ├── data/
            │   ├── Models.kt            # OtType, DayEntry, AppSettings, ThemeMode
            │   └── Repository.kt        # Lưu dữ liệu (SharedPreferences + JSON)
            ├── logic/
            │   ├── SalaryCalculator.kt  # Công thức lương
            │   └── LoanCalculator.kt    # Bảng trả nợ
            ├── viewmodel/MainViewModel.kt
            ├── util/Fmt.kt              # Định dạng tiền, giờ, ngày kiểu VN
            └── ui/
                ├── theme/Color.kt, Theme.kt   # Giao diện sáng/tối
                ├── components/Common.kt       # Card, ô nhập tiền, chọn tháng...
                └── screens/
                    ├── CalendarScreen.kt      # Tab 1: lịch tháng
                    ├── DayEditorDialog.kt     # Hộp nhập giờ khi chạm vào ngày
                    ├── StatsScreen.kt         # Tab 2: thống kê lương
                    ├── LoanScreen.kt          # Tab 3: vay nợ
                    └── SettingsScreen.kt      # Tab 4: cài đặt
```

## Đẩy lên GitHub và build APK

1. Tạo repository mới, đẩy toàn bộ thư mục `OvertimeManager` lên (nhánh `main`).
2. Vào tab **Actions** → workflow **Build APK** sẽ tự chạy (hoặc bấm *Run workflow*).
3. Khi chạy xong, tải file **OvertimeManager-debug-apk** ở mục *Artifacts*, giải nén, cài file `.apk` lên điện thoại.

Workflow dùng Gradle do action cài sẵn nên **không cần** `gradlew` hay `gradle-wrapper.jar`.

## Công thức tính (có thể chỉnh trong `logic/`)

- Đơn giá giờ = (Lương cố định + Trợ cấp) ÷ 192
- Lương tăng ca = Số giờ × Đơn giá giờ × Hệ số (1,5 / 2,1 / 2,0 / 2,7 / 3,0 / 3,9)
- Trừ ra ngoài = Số giờ ra ngoài × Đơn giá giờ
- Thực nhận = Lương gốc + Trợ cấp + Lương tăng ca − Ra ngoài − Thuế khấu trừ
- Vay nợ: gốc trả cố định mỗi tháng; Lãi = Dư nợ đầu kỳ × Lãi năm ÷ 12; Tổng trả = Gốc + Lãi
