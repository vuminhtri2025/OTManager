package com.otmanager.app.data

import android.content.Context
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth

/** Lưu/đọc dữ liệu cục bộ bằng SharedPreferences (JSON), không cần thư viện ngoài. */
class Repository(context: Context) {

    private val prefs =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadSettings(): AppSettings {
        val raw = prefs.getString(KEY_SETTINGS, null) ?: return AppSettings()
        return try {
            val o = JSONObject(raw)
            val d = AppSettings()
            AppSettings(
                baseSalary = o.optLong("baseSalary", d.baseSalary),
                allowance = o.optLong("allowance", d.allowance),
                taxDeduction = o.optLong("taxDeduction", d.taxDeduction),
                loanPrincipal = o.optLong("loanPrincipal", d.loanPrincipal),
                loanAnnualRate = o.optDouble("loanAnnualRate", d.loanAnnualRate),
                loanFixedPayment = o.optLong("loanFixedPayment", d.loanFixedPayment),
                loanStartMonth = try {
                    YearMonth.parse(o.optString("loanStartMonth"))
                } catch (e: Exception) {
                    d.loanStartMonth
                },
                themeMode = try {
                    ThemeMode.valueOf(o.optString("themeMode"))
                } catch (e: Exception) {
                    ThemeMode.SYSTEM
                }
            )
        } catch (e: Exception) {
            AppSettings()
        }
    }

    fun saveSettings(s: AppSettings) {
        val o = JSONObject()
        o.put("baseSalary", s.baseSalary)
        o.put("allowance", s.allowance)
        o.put("taxDeduction", s.taxDeduction)
        o.put("loanPrincipal", s.loanPrincipal)
        o.put("loanAnnualRate", s.loanAnnualRate)
        o.put("loanFixedPayment", s.loanFixedPayment)
        o.put("loanStartMonth", s.loanStartMonth.toString())
        o.put("themeMode", s.themeMode.name)
        prefs.edit().putString(KEY_SETTINGS, o.toString()).apply()
    }

    fun loadEntries(): Map<LocalDate, DayEntry> {
        val raw = prefs.getString(KEY_ENTRIES, null) ?: return emptyMap()
        return try {
            val root = JSONObject(raw)
            val result = HashMap<LocalDate, DayEntry>()
            val keys = root.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val date = LocalDate.parse(k)
                val o = root.getJSONObject(k)
                val hours = HashMap<OtType, Double>()
                for (t in OtType.values()) {
                    val h = o.optDouble(t.key, 0.0)
                    if (h > 0.0) hours[t] = h
                }
                val entry = DayEntry(hours, o.optDouble("out", 0.0))
                if (!entry.isEmpty) result[date] = entry
            }
            result
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun saveEntries(entries: Map<LocalDate, DayEntry>) {
        val root = JSONObject()
        for ((date, entry) in entries) {
            if (entry.isEmpty) continue
            val o = JSONObject()
            for ((type, h) in entry.hours) {
                if (h > 0.0) o.put(type.key, h)
            }
            if (entry.outHours > 0.0) o.put("out", entry.outHours)
            root.put(date.toString(), o)
        }
        prefs.edit().putString(KEY_ENTRIES, root.toString()).apply()
    }

    private companion object {
        const val PREFS_NAME = "ot_manager_prefs"
        const val KEY_SETTINGS = "settings"
        const val KEY_ENTRIES = "entries"
    }
}
