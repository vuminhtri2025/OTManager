package com.otmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.otmanager.app.data.AppSettings
import com.otmanager.app.data.ThemeMode
import com.otmanager.app.ui.components.AppCard
import com.otmanager.app.ui.components.DecimalField
import com.otmanager.app.ui.components.MonthPickerDialog
import com.otmanager.app.ui.components.MoneyField
import com.otmanager.app.ui.components.Pill
import com.otmanager.app.ui.components.ScreenTitle
import com.otmanager.app.ui.components.SectionTitle
import com.otmanager.app.util.Fmt

@Composable
fun SettingsScreen(settings: AppSettings, onChange: (AppSettings) -> Unit) {
    val c = MaterialTheme.colorScheme
    var showMonthPicker by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("Cài đặt", "Mọi thay đổi được lưu tự động")

        AppCard {
            SectionTitle("Lương")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MoneyField("Lương gốc", settings.baseSalary, { onChange(settings.copy(baseSalary = it)) })
                MoneyField("Mức trợ cấp", settings.allowance, { onChange(settings.copy(allowance = it)) })
                MoneyField(
                    label = "Thuế khấu trừ",
                    value = settings.taxDeduction,
                    onValueChange = { onChange(settings.copy(taxDeduction = it)) },
                    supporting = "Số tiền cố định trừ mỗi tháng"
                )
                Text(
                    text = "Đơn giá giờ = (lương gốc + trợ cấp) ÷ 192 = " +
                        Fmt.money(com.otmanager.app.logic.SalaryCalculator.hourlyRate(settings)),
                    style = MaterialTheme.typography.bodySmall,
                    color = c.primary
                )
            }
        }

        AppCard {
            SectionTitle("Vay nợ")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MoneyField("Tiền gốc vay ban đầu", settings.loanPrincipal, { onChange(settings.copy(loanPrincipal = it)) })
                DecimalField(
                    label = "Lãi suất vay (năm)",
                    value = settings.loanAnnualRate,
                    onValueChange = { onChange(settings.copy(loanAnnualRate = it)) },
                    suffix = "%/năm"
                )
                MoneyField(
                    label = "Tiền gốc trả cố định / tháng",
                    value = settings.loanFixedPayment,
                    onValueChange = { onChange(settings.copy(loanFixedPayment = it)) }
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Tháng bắt đầu trả",
                        style = MaterialTheme.typography.bodyLarge,
                        color = c.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    Pill(
                        text = Fmt.monthShort(settings.loanStartMonth),
                        selected = true,
                        onClick = { showMonthPicker = true }
                    )
                }
            }
        }

        AppCard {
            SectionTitle("Giao diện")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Pill("Hệ thống", settings.themeMode == ThemeMode.SYSTEM, { onChange(settings.copy(themeMode = ThemeMode.SYSTEM)) }, Modifier.weight(1f))
                Pill("Sáng", settings.themeMode == ThemeMode.LIGHT, { onChange(settings.copy(themeMode = ThemeMode.LIGHT)) }, Modifier.weight(1f))
                Pill("Tối", settings.themeMode == ThemeMode.DARK, { onChange(settings.copy(themeMode = ThemeMode.DARK)) }, Modifier.weight(1f))
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
    }

    if (showMonthPicker) {
        MonthPickerDialog(
            initial = settings.loanStartMonth,
            onSelected = {
                onChange(settings.copy(loanStartMonth = it))
                showMonthPicker = false
            },
            onDismiss = { showMonthPicker = false }
        )
    }
}
