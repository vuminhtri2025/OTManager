package com.otmanager.app.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.otmanager.app.data.AppSettings
import com.otmanager.app.data.DayEntry
import com.otmanager.app.data.Repository
import java.time.LocalDate
import java.time.YearMonth

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository(app)

    var settings by mutableStateOf(repo.loadSettings())
        private set

    var entries by mutableStateOf(repo.loadEntries())
        private set

    var selectedMonth by mutableStateOf(YearMonth.now())
        private set

    fun updateSettings(new: AppSettings) {
        settings = new
        repo.saveSettings(new)
    }

    fun saveEntry(date: LocalDate, entry: DayEntry) {
        val map = entries.toMutableMap()
        if (entry.isEmpty) map.remove(date) else map[date] = entry
        entries = map
        repo.saveEntries(map)
    }

    fun selectMonth(month: YearMonth) {
        selectedMonth = month
    }
}
