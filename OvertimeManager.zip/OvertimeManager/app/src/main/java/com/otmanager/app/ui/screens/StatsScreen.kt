package com.otmanager.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.otmanager.app.data.AppSettings
import com.otmanager.app.data.DayEntry
import com.otmanager.app.logic.SalaryCalculator
import com.otmanager.app.ui.components.AmountRow
import com.otmanager.app.ui.components.AppCard
import com.otmanager.app.ui.components.GradientCard
import com.otmanager.app.ui.components.MonthNavigator
import com.otmanager.app.ui.components.ScreenTitle
import com.otmanager.app.ui.components.SectionTitle
import com.otmanager.app.ui.theme.OutColor
import com.otmanager.app.util.Fmt
import java.time.LocalDate
import java.time.YearMonth

private val Positive = Color(0xFF10B981)

@Composable
fun StatsScreen(
    month: YearMonth,
    entries: Map<LocalDate, DayEntry>,
    settings: AppSettings,
    onMonthChange: (YearMonth) -> Unit
) {
    val r = SalaryCalculator.calculate(month, entries, settings)
    val c = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("Thống kê lương", "Lương thực nhận theo từng tháng")
        MonthNavigator(month = month, onChange = onMonthChange)

        GradientCard {
            Text(
                text = "Thực nhận ${Fmt.monthTitle(month).lowercase()}",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.85f)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = Fmt.money(r.net),
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Tổng thu ${Fmt.money(r.gross)} · Tổng trừ ${Fmt.money(r.totalDeduction)}",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.85f)
            )
        }

        if (settings.baseSalary <= 0L) {
            AppCard {
                Text(
                    text = "Bạn chưa cài đặt lương gốc. Hãy vào tab Cài đặt để nhập mức lương.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.onSurfaceVariant
                )
            }
        }

        AppCard {
            SectionTitle("Khoản thu")
            AmountRow("Lương gốc", Fmt.money(r.baseSalary))
            AmountRow("Trợ cấp", Fmt.money(r.allowance))
            AmountRow(
                label = "Lương tăng ca",
                amount = "+ " + Fmt.money(r.totalOtPay),
                subtitle = "${Fmt.hours(r.totalOtHours)} giờ · đơn giá ${Fmt.money(r.hourlyRate)}/giờ",
                amountColor = Positive
            )
            for (line in r.otLines) {
                if (line.hours > 0.0) {
                    AmountRow(
                        label = "${line.type.label} × ${Fmt.hours(line.hours)} giờ",
                        amount = Fmt.money(line.amount),
                        indent = true
                    )
                }
            }
            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = c.outlineVariant)
            AmountRow("Tổng thu", Fmt.money(r.gross), bold = true)
        }

        AppCard {
            SectionTitle("Khoản trừ")
            AmountRow(
                label = "Thời gian ra ngoài",
                amount = "- " + Fmt.money(r.outDeduction),
                subtitle = "${Fmt.hours(r.outHours)} giờ × ${Fmt.money(r.hourlyRate)}",
                amountColor = OutColor
            )
            AmountRow(
                label = "Thuế khấu trừ",
                amount = "- " + Fmt.money(r.tax),
                amountColor = OutColor
            )
            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = c.outlineVariant)
            AmountRow("Tổng trừ", "- " + Fmt.money(r.totalDeduction), bold = true)
        }

        AppCard {
            SectionTitle("Công thức")
            Text(
                text = "Thực nhận = Lương gốc + Trợ cấp + Lương tăng ca − Ra ngoài − Thuế\n" +
                    "Đơn giá giờ = (Lương gốc + Trợ cấp) ÷ 192\n" +
                    "Lương tăng ca = Số giờ × Đơn giá giờ × Hệ số (150%, 210%…)",
                style = MaterialTheme.typography.bodySmall,
                color = c.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
    }
}
