package com.otmanager.app.logic

import com.otmanager.app.data.AppSettings
import java.time.YearMonth

data class LoanRow(
    val index: Int,
    val month: YearMonth,
    val fixedPayment: Long,     // Tiền gốc trả cố định trong kỳ
    val monthlyRate: Double,    // Lãi suất tháng (%)
    val interest: Long,         // Tiền lãi = dư nợ đầu kỳ × lãi suất tháng
    val endingBalance: Long,    // Dư nợ cuối kỳ
    val totalPayment: Long      // Tổng tiền trả = gốc + lãi
)

data class LoanSummary(
    val rows: List<LoanRow>,
    val principal: Long,
    val remainingDebt: Long,
    val paidPrincipal: Long,
    val paidMonths: Int,
    val totalMonths: Int,
    val totalInterest: Long,
    val totalPaid: Long,
    val currentIndex: Int
)

/**
 * Phương pháp: trả GỐC CỐ ĐỊNH mỗi kỳ, lãi tính trên dư nợ đầu kỳ (giảm dần).
 *   Lãi tháng = Dư nợ đầu kỳ × (lãi suất năm ÷ 12)
 *   Tổng trả  = Gốc cố định + Lãi tháng
 */
object LoanCalculator {
    private const val MAX_ROWS = 600

    fun build(s: AppSettings, now: YearMonth = YearMonth.now()): LoanSummary {
        if (s.loanPrincipal <= 0L || s.loanFixedPayment <= 0L) {
            return LoanSummary(
                rows = emptyList(),
                principal = s.loanPrincipal,
                remainingDebt = s.loanPrincipal.coerceAtLeast(0L),
                paidPrincipal = 0L,
                paidMonths = 0,
                totalMonths = 0,
                totalInterest = 0L,
                totalPaid = 0L,
                currentIndex = -1
            )
        }

        val monthlyRate = s.loanAnnualRate / 12.0
        val rows = ArrayList<LoanRow>()
        var balance = s.loanPrincipal
        var month = s.loanStartMonth
        var idx = 1

        while (balance > 0L && idx <= MAX_ROWS) {
            val interest = Math.round(balance * monthlyRate / 100.0)
            val pay = minOf(s.loanFixedPayment, balance)
            val ending = balance - pay
            rows.add(LoanRow(idx, month, pay, monthlyRate, interest, ending, pay + interest))
            balance = ending
            month = month.plusMonths(1)
            idx++
        }

        // Các kỳ có tháng <= tháng hiện tại được tính là đã trả.
        val paidMonths = rows.count { !it.month.isAfter(now) }
        val remaining = if (paidMonths == 0) s.loanPrincipal else rows[paidMonths - 1].endingBalance

        return LoanSummary(
            rows = rows,
            principal = s.loanPrincipal,
            remainingDebt = remaining,
            paidPrincipal = s.loanPrincipal - remaining,
            paidMonths = paidMonths,
            totalMonths = rows.size,
            totalInterest = rows.sumOf { it.interest },
            totalPaid = rows.sumOf { it.totalPayment },
            currentIndex = rows.indexOfFirst { it.month == now }
        )
    }
}
