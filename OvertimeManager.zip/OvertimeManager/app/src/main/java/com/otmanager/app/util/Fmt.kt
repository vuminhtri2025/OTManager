package com.otmanager.app.util

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

/** Định dạng số/ngày theo kiểu Việt Nam (1.234.567 ₫, 2,5 giờ). */
object Fmt {
    private val vnSymbols = DecimalFormatSymbols(Locale.US).apply {
        groupingSeparator = '.'
        decimalSeparator = ','
    }
    private val plainSymbols = DecimalFormatSymbols(Locale.US)

    fun number(v: Long): String = DecimalFormat("#,##0", vnSymbols).format(v)

    fun money(v: Long): String = number(v) + " ₫"

    fun money(v: Double): String = money(Math.round(v))

    fun hours(v: Double): String = DecimalFormat("0.##", vnSymbols).format(v)

    fun percent(v: Double): String = DecimalFormat("0.###", vnSymbols).format(v) + "%"

    /** Chuỗi số thuần (dấu chấm thập phân) dùng để đưa vào ô nhập; 0 → rỗng. */
    fun plain(v: Double): String =
        if (v == 0.0) "" else DecimalFormat("0.####", plainSymbols).format(v)

    fun parseDecimal(text: String): Double? = text.trim().replace(',', '.').toDoubleOrNull()

    fun monthTitle(ym: YearMonth): String = "Tháng ${ym.monthValue}/${ym.year}"

    fun monthShort(ym: YearMonth): String = "%02d/%d".format(ym.monthValue, ym.year)

    fun weekdayShort(d: DayOfWeek): String = when (d) {
        DayOfWeek.MONDAY -> "T2"
        DayOfWeek.TUESDAY -> "T3"
        DayOfWeek.WEDNESDAY -> "T4"
        DayOfWeek.THURSDAY -> "T5"
        DayOfWeek.FRIDAY -> "T6"
        DayOfWeek.SATURDAY -> "T7"
        DayOfWeek.SUNDAY -> "CN"
    }

    fun weekdayLong(d: DayOfWeek): String = when (d) {
        DayOfWeek.MONDAY -> "Thứ hai"
        DayOfWeek.TUESDAY -> "Thứ ba"
        DayOfWeek.WEDNESDAY -> "Thứ tư"
        DayOfWeek.THURSDAY -> "Thứ năm"
        DayOfWeek.FRIDAY -> "Thứ sáu"
        DayOfWeek.SATURDAY -> "Thứ bảy"
        DayOfWeek.SUNDAY -> "Chủ nhật"
    }

    fun dayLabel(d: LocalDate): String =
        "${weekdayLong(d.dayOfWeek)}, %02d/%02d/%d".format(d.dayOfMonth, d.monthValue, d.year)

    fun shortDate(d: LocalDate): String =
        "%02d/%02d (%s)".format(d.dayOfMonth, d.monthValue, weekdayShort(d.dayOfWeek))
}
