package com.otmanager.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.otmanager.app.util.Fmt
import java.time.YearMonth

// ---------------------------------------------------------------------------
// Thẻ & tiêu đề
// ---------------------------------------------------------------------------

@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun GradientCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = MaterialTheme.colorScheme
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(c.primary, c.tertiary)))
            .padding(20.dp)
    ) {
        Column(content = content)
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        if (subtitle != null) {
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = modifier.padding(bottom = 8.dp)
    )
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) c.primary else c.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (selected) c.onPrimary else c.onSurfaceVariant,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

/** Một dòng "nhãn ..... số tiền" dùng trong màn hình thống kê. */
@Composable
fun AmountRow(
    label: String,
    amount: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    amountColor: Color = Color.Unspecified,
    bold: Boolean = false,
    indent: Boolean = false
) {
    val c = MaterialTheme.colorScheme
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .padding(start = if (indent) 14.dp else 0.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = if (indent) MaterialTheme.typography.bodySmall else MaterialTheme.typography.bodyLarge,
                color = if (indent) c.onSurfaceVariant else c.onSurface,
                fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = c.onSurfaceVariant
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = amount,
            style = if (indent) MaterialTheme.typography.bodySmall else MaterialTheme.typography.bodyLarge,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.SemiBold,
            color = if (amountColor == Color.Unspecified) c.onSurface else amountColor
        )
    }
}

// ---------------------------------------------------------------------------
// Chọn tháng
// ---------------------------------------------------------------------------

@Composable
fun MonthNavigator(
    month: YearMonth,
    onChange: (YearMonth) -> Unit,
    modifier: Modifier = Modifier
) {
    var showPicker by remember { mutableStateOf(false) }

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        IconButton(onClick = { onChange(month.minusMonths(1)) }) {
            Icon(Icons.Rounded.ChevronLeft, contentDescription = "Tháng trước")
        }
        Text(
            text = Fmt.monthTitle(month),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { showPicker = true }
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )
        IconButton(onClick = { onChange(month.plusMonths(1)) }) {
            Icon(Icons.Rounded.ChevronRight, contentDescription = "Tháng sau")
        }
    }

    if (showPicker) {
        MonthPickerDialog(
            initial = month,
            onSelected = {
                onChange(it)
                showPicker = false
            },
            onDismiss = { showPicker = false }
        )
    }
}

@Composable
fun MonthPickerDialog(
    initial: YearMonth,
    onSelected: (YearMonth) -> Unit,
    onDismiss: () -> Unit
) {
    var year by remember { mutableIntStateOf(initial.year) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Đóng") } },
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { year -= 1 }) {
                    Icon(Icons.Rounded.ChevronLeft, contentDescription = "Năm trước")
                }
                Text(text = "$year", fontWeight = FontWeight.Bold)
                IconButton(onClick = { year += 1 }) {
                    Icon(Icons.Rounded.ChevronRight, contentDescription = "Năm sau")
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (row in 0 until 4) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (col in 0 until 3) {
                            val m = row * 3 + col + 1
                            Pill(
                                text = "Th $m",
                                selected = year == initial.year && m == initial.monthValue,
                                onClick = { onSelected(YearMonth.of(year, m)) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    )
}

// ---------------------------------------------------------------------------
// Ô nhập liệu
// ---------------------------------------------------------------------------

/** Hiển thị số nguyên với dấu chấm ngăn cách hàng nghìn (1234567 → 1.234.567). */
class ThousandsTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val sb = StringBuilder()
        val originalToTransformed = IntArray(s.length + 1)
        val transformedToOriginal = ArrayList<Int>()
        transformedToOriginal.add(0)
        var digits = 0

        for (i in s.indices) {
            if (i > 0 && (s.length - i) % 3 == 0) {
                sb.append('.')
                transformedToOriginal.add(digits)
            }
            originalToTransformed[i] = sb.length
            sb.append(s[i])
            digits++
            transformedToOriginal.add(digits)
        }
        originalToTransformed[s.length] = sb.length

        val mapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int =
                originalToTransformed[offset.coerceIn(0, s.length)]

            override fun transformedToOriginal(offset: Int): Int =
                transformedToOriginal[offset.coerceIn(0, sb.length)]
        }
        return TransformedText(AnnotatedString(sb.toString()), mapping)
    }
}

@Composable
fun MoneyField(
    label: String,
    value: Long,
    onValueChange: (Long) -> Unit,
    modifier: Modifier = Modifier,
    supporting: String? = null
) {
    OutlinedTextField(
        value = if (value == 0L) "" else value.toString(),
        onValueChange = { raw ->
            onValueChange(raw.filter { it.isDigit() }.take(13).toLongOrNull() ?: 0L)
        },
        label = { Text(label) },
        suffix = { Text("₫") },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        visualTransformation = ThousandsTransformation(),
        shape = RoundedCornerShape(16.dp),
        supportingText = if (supporting != null) {
            { Text(supporting) }
        } else null,
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun DecimalField(
    label: String,
    value: Double,
    onValueChange: (Double) -> Unit,
    modifier: Modifier = Modifier,
    suffix: String? = null,
    supporting: String? = null
) {
    var text by remember { mutableStateOf(Fmt.plain(value)) }

    OutlinedTextField(
        value = text,
        onValueChange = { raw ->
            val cleaned = raw.replace(',', '.').filter { it.isDigit() || it == '.' }
            if (cleaned.count { it == '.' } <= 1 && cleaned.length <= 10) {
                text = cleaned
                onValueChange(cleaned.toDoubleOrNull() ?: 0.0)
            }
        },
        label = { Text(label) },
        suffix = if (suffix != null) {
            { Text(suffix) }
        } else null,
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        shape = RoundedCornerShape(16.dp),
        supportingText = if (supporting != null) {
            { Text(supporting) }
        } else null,
        modifier = modifier.fillMaxWidth()
    )
}
