package com.otmanager.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.otmanager.app.data.AppSettings
import com.otmanager.app.logic.LoanCalculator
import com.otmanager.app.logic.LoanRow
import com.otmanager.app.ui.components.AppCard
import com.otmanager.app.ui.components.GradientCard
import com.otmanager.app.ui.components.ScreenTitle
import com.otmanager.app.ui.components.SectionTitle
import com.otmanager.app.util.Fmt

private val ColMonth = 84.dp
private val ColFixed = 116.dp
private val ColRate = 80.dp
private val ColInterest = 104.dp
private val ColBalance = 124.dp
private val ColTotal = 124.dp

@Composable
fun LoanScreen(settings: AppSettings) {
    val summary = LoanCalculator.build(settings)
    val c = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("Vay nợ", "Theo dõi dư nợ và lịch trả")

        GradientCard {
            Text(
                text = "Số nợ còn lại",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.85f)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = Fmt.money(summary.remainingDebt),
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
            if (summary.principal > 0L) {
                Spacer(modifier = Modifier.height(12.dp))
                val progress = (summary.paidPrincipal.toFloat() / summary.principal.toFloat())
                    .coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.3f)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Đã trả ${Fmt.money(summary.paidPrincipal)} / ${Fmt.money(summary.principal)} · " +
                        "${summary.paidMonths}/${summary.totalMonths} kỳ",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }

        if (summary.rows.isEmpty()) {
            AppCard {
                Text(
                    text = "Chưa có khoản vay. Vào tab Cài đặt để nhập tiền gốc vay, lãi suất năm và số tiền trả cố định mỗi tháng.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.onSurfaceVariant
                )
            }
        } else {
            AppCard {
                SectionTitle("Tổng quan")
                Row(modifier = Modifier.fillMaxWidth()) {
                    Overview("Tổng lãi", Fmt.money(summary.totalInterest), Modifier.weight(1f))
                    Overview("Tổng phải trả", Fmt.money(summary.totalPaid), Modifier.weight(1f))
                }
            }

            AppCard {
                SectionTitle("Lịch trả nợ")
                Text(
                    text = "Vuốt ngang để xem đủ các cột",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Column(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    HeaderRow()
                    summary.rows.forEach { row ->
                        DataRow(row, highlight = row.month == java.time.YearMonth.now())
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
    }
}

@Composable
private fun Overview(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun HeaderRow() {
    val c = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(c.primaryContainer)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Cell("Tháng trả nợ", ColMonth, header = true, align = TextAlign.Center)
        Cell("Tiền trả cố định", ColFixed, header = true)
        Cell("Lãi suất", ColRate, header = true)
        Cell("Tiền lãi", ColInterest, header = true)
        Cell("Dư nợ cuối kỳ", ColBalance, header = true)
        Cell("Tổng tiền trả", ColTotal, header = true)
    }
}

@Composable
private fun DataRow(row: LoanRow, highlight: Boolean) {
    val c = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (highlight) c.secondaryContainer else Color.Transparent)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Cell(Fmt.monthShort(row.month), ColMonth, align = TextAlign.Center, bold = true)
        Cell(Fmt.number(row.fixedPayment), ColFixed)
        Cell(Fmt.percent(row.monthlyRate) + "/th", ColRate)
        Cell(Fmt.number(row.interest), ColInterest)
        Cell(Fmt.number(row.endingBalance), ColBalance)
        Cell(Fmt.number(row.totalPayment), ColTotal, bold = true)
    }
}

@Composable
private fun Cell(
    text: String,
    width: Dp,
    header: Boolean = false,
    bold: Boolean = false,
    align: TextAlign = TextAlign.End
) {
    val c = MaterialTheme.colorScheme
    Box(modifier = Modifier.width(width).padding(horizontal = 8.dp)) {
        Text(
            text = text,
            modifier = Modifier.fillMaxWidth(),
            textAlign = align,
            maxLines = if (header) 2 else 1,
            style = if (header) MaterialTheme.typography.labelMedium else MaterialTheme.typography.bodySmall,
            fontWeight = if (header || bold) FontWeight.Bold else FontWeight.Normal,
            color = if (header) c.onPrimaryContainer else c.onSurface
        )
    }
}
