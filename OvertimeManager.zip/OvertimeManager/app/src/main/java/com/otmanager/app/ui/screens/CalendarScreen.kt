package com.otmanager.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.otmanager.app.data.DayEntry
import com.otmanager.app.data.OtType
import com.otmanager.app.ui.components.AppCard
import com.otmanager.app.ui.components.MonthNavigator
import com.otmanager.app.ui.components.ScreenTitle
import com.otmanager.app.ui.components.SectionTitle
import com.otmanager.app.ui.theme.OutColor
import com.otmanager.app.ui.theme.otColor
import com.otmanager.app.util.Fmt
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun CalendarScreen(
    month: YearMonth,
    entries: Map<LocalDate, DayEntry>,
    onMonthChange: (YearMonth) -> Unit,
    onSaveEntry: (LocalDate, DayEntry) -> Unit
) {
    var selected by remember { mutableStateOf<LocalDate?>(null) }

    val monthEntries = entries.filter { YearMonth.from(it.key) == month }
    val hoursByType = OtType.values().associateWith { t ->
        monthEntries.values.sumOf { it.hoursOf(t) }
    }
    val totalOt = hoursByType.values.sum()
    val totalOut = monthEntries.values.sumOf { it.outHours }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("Lịch tăng ca", "Chạm vào một ngày để nhập số giờ")
        MonthNavigator(month = month, onChange = onMonthChange)

        AppCard {
            MonthGrid(
                month = month,
                entries = entries,
                onDayClick = { selected = it }
            )
        }

        AppCard {
            SectionTitle("Tổng kết ${Fmt.monthTitle(month).lowercase()}")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SummaryStat("Tổng tăng ca", "${Fmt.hours(totalOt)} giờ", MaterialTheme.colorScheme.primary)
                SummaryStat("Ra ngoài", "${Fmt.hours(totalOut)} giờ", OutColor)
            }
            Spacer(modifier = Modifier.height(12.dp))
            for (t in OtType.values()) {
                val h = hoursByType[t] ?: 0.0
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(otColor(t))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "${t.label} · ${t.hint}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "${Fmt.hours(h)} giờ",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (h > 0) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
    }

    selected?.let { date ->
        DayEditorDialog(
            date = date,
            initial = entries[date] ?: DayEntry(),
            onDismiss = { selected = null },
            onSave = {
                onSaveEntry(date, it)
                selected = null
            }
        )
    }
}

@Composable
private fun SummaryStat(label: String, value: String, color: Color) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
private fun MonthGrid(
    month: YearMonth,
    entries: Map<LocalDate, DayEntry>,
    onDayClick: (LocalDate) -> Unit
) {
    val c = MaterialTheme.colorScheme
    val today = LocalDate.now()
    val firstOffset = month.atDay(1).dayOfWeek.value - 1 // Thứ hai = 0
    val days = month.lengthOfMonth()
    val weeks = (firstOffset + days + 6) / 7
    val weekdays = listOf(
        DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY,
        DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY
    )

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(modifier = Modifier.fillMaxWidth()) {
            for (d in weekdays) {
                Text(
                    text = Fmt.weekdayShort(d),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (d == DayOfWeek.SUNDAY) c.error else c.onSurfaceVariant
                )
            }
        }
        for (w in 0 until weeks) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (col in 0 until 7) {
                    val dayNum = w * 7 + col - firstOffset + 1
                    Box(modifier = Modifier.weight(1f)) {
                        if (dayNum in 1..days) {
                            val date = month.atDay(dayNum)
                            DayCell(
                                date = date,
                                entry = entries[date],
                                isToday = date == today,
                                onClick = { onDayClick(date) }
                            )
                        } else {
                            Spacer(modifier = Modifier.aspectRatio(0.82f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    date: LocalDate,
    entry: DayEntry?,
    isToday: Boolean,
    onClick: () -> Unit
) {
    val c = MaterialTheme.colorScheme
    val hasData = entry != null && !entry.isEmpty
    val isSunday = date.dayOfWeek == DayOfWeek.SUNDAY
    val shape = RoundedCornerShape(14.dp)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.82f)
            .clip(shape)
            .background(if (hasData) c.primaryContainer.copy(alpha = 0.55f) else c.surfaceVariant.copy(alpha = 0.55f))
            .then(
                if (isToday) Modifier.border(BorderStroke(2.dp, c.primary), shape)
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "${date.dayOfMonth}",
            fontSize = 14.sp,
            fontWeight = if (isToday) FontWeight.ExtraBold else FontWeight.SemiBold,
            color = when {
                isToday -> c.primary
                isSunday -> c.error
                else -> c.onSurface
            }
        )

        if (hasData && entry != null) {
            val types = OtType.values().filter { entry.hoursOf(it) > 0.0 }
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                for (t in types.take(3)) {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(otColor(t))
                    )
                }
                if (entry.outHours > 0.0) {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(OutColor)
                    )
                }
            }
            val label = buildString {
                if (entry.totalOt > 0.0) append("+${Fmt.hours(entry.totalOt)}h")
                if (entry.outHours > 0.0) {
                    if (isNotEmpty()) append(' ')
                    append("-${Fmt.hours(entry.outHours)}")
                }
            }
            Text(
                text = label,
                fontSize = 9.sp,
                maxLines = 1,
                fontWeight = FontWeight.Bold,
                color = c.onSurfaceVariant
            )
        } else {
            Spacer(modifier = Modifier.height(1.dp))
        }
    }
}
