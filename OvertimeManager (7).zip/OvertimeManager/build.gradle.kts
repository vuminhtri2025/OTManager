// Cấu hình cấp dự án: chỉ khai báo phiên bản plugin, module app sẽ áp dụng.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
