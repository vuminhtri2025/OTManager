plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.otmanager.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.otmanager.app"
        minSdk = 26
        targetSdk = 34
        // Trên GitHub, versionCode tăng theo số lần chạy workflow để luôn cài đè được.
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "1.0.0"
    }

    // Ký bằng keystore cố định nằm trong dự án (app/keystore/otmanager.jks).
    // Mọi bản build cùng một chữ ký => cài bản mới đè lên bản cũ, không mất dữ liệu.
    signingConfigs {
        create("app") {
            storeFile = file("keystore/otmanager.jks")
            storePassword = "PG0C0Kes1xYqAyx6X9MiFjPB"
            keyAlias = "otmanager"
            keyPassword = "PG0C0Kes1xYqAyx6X9MiFjPB"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("app")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("app")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        // Tương thích với Kotlin 1.9.24
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.activity:activity-compose:1.9.2")

    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
}
