package com.otmanager.app.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.otmanager.app.data.AppSettings
import com.otmanager.app.data.DayEntry
import com.otmanager.app.data.LoanEvent
import com.otmanager.app.data.Repository
import com.otmanager.app.widget.OtWidgetProvider
import java.time.LocalDate
import java.time.YearMonth

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repository(app)

    var settings by mutableStateOf(repo.loadSettings())
        private set

    var entries by mutableStateOf(repo.loadEntries())
        private set

    var loanEvents by mutableStateOf(repo.loadLoanEvents())
        private set

    var selectedMonth by mutableStateOf(YearMonth.now())
        private set

    fun updateSettings(new: AppSettings) {
        settings = new
        repo.saveSettings(new)
    }

    fun saveEntry(date: LocalDate, entry: DayEntry) {
        val map = entries.toMutableMap()
        if (entry.isEmpty) map.remove(date) else map[date] = entry
        entries = map
        repo.saveEntries(map)
        // Cập nhật widget ngoài màn hình chính
        OtWidgetProvider.refresh(getApplication<Application>())
    }

    /** Thêm kỳ trả nợ mới, hoặc cập nhật nếu đã có kỳ cùng id. */
    fun saveLoanEvent(event: LoanEvent) {
        val list = if (loanEvents.any { it.id == event.id }) {
            loanEvents.map { if (it.id == event.id) event else it }
        } else {
            loanEvents + event
        }
        loanEvents = list
        repo.saveLoanEvents(list)
    }

    fun removeLoanEvent(id: Long) {
        val list = loanEvents.filter { it.id != id }
        loanEvents = list
        repo.saveLoanEvents(list)
    }

    fun exportBackup(): String = repo.exportJson()

    /** Khôi phục dữ liệu từ nội dung file sao lưu; trả về true nếu thành công. */
    fun importBackup(text: String): Boolean {
        if (!repo.importJson(text)) return false
        settings = repo.loadSettings()
        entries = repo.loadEntries()
        loanEvents = repo.loadLoanEvents()
        OtWidgetProvider.refresh(getApplication<Application>())
        return true
    }

    fun selectMonth(month: YearMonth) {
        selectedMonth = month
    }
}
