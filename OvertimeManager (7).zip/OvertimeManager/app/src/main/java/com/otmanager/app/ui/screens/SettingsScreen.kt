package com.otmanager.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.otmanager.app.data.AppSettings
import com.otmanager.app.data.ThemeMode
import com.otmanager.app.logic.SalaryCalculator
import com.otmanager.app.ui.components.AppCard
import com.otmanager.app.ui.components.DecimalField
import com.otmanager.app.ui.components.MoneyField
import com.otmanager.app.ui.components.Pill
import com.otmanager.app.ui.components.ScreenTitle
import com.otmanager.app.ui.components.SectionTitle
import com.otmanager.app.util.Fmt
import java.time.LocalDate

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onChange: (AppSettings) -> Unit,
    exportData: () -> String,
    importData: (String) -> Boolean
) {
    val c = MaterialTheme.colorScheme
    val context = LocalContext.current
    var confirmRestore by remember { mutableStateOf(false) }
    var backupMessage by remember { mutableStateOf<String?>(null) }
    // Đổi giá trị này để các ô nhập tự làm mới sau khi khôi phục dữ liệu
    var resetKey by remember { mutableIntStateOf(0) }

    // Các thay đổi được giữ trong bản nháp và chỉ áp dụng khi bấm nút Lưu.
    var draft by remember(settings) { mutableStateOf(settings) }
    var justSaved by remember { mutableStateOf(false) }
    val hasChanges = draft != settings
    val edit: (AppSettings) -> Unit = {
        draft = it
        justSaved = false
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            backupMessage = try {
                context.contentResolver.openOutputStream(uri)?.use {
                    it.write(exportData().toByteArray(Charsets.UTF_8))
                }
                "Đã sao lưu dữ liệu thành công."
            } catch (e: Exception) {
                "Sao lưu thất bại, vui lòng thử lại."
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            backupMessage = try {
                val text = context.contentResolver.openInputStream(uri)?.use {
                    it.readBytes().toString(Charsets.UTF_8)
                }
                if (text != null && importData(text)) {
                    resetKey++
                    "Đã khôi phục dữ liệu thành công."
                } else {
                    "File sao lưu không hợp lệ, dữ liệu hiện tại được giữ nguyên."
                }
            } catch (e: Exception) {
                "Không đọc được file, vui lòng thử lại."
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            ScreenTitle(
                "Cài đặt",
                when {
                    hasChanges -> "Có thay đổi chưa lưu · nhấn Lưu để áp dụng"
                    justSaved -> "Đã lưu cài đặt"
                    else -> "Chỉnh thông tin rồi nhấn Lưu"
                }
            )

            AppCard {
                SectionTitle("Lương")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyField("Lương gốc", draft.baseSalary, { edit(draft.copy(baseSalary = it)) })
                    MoneyField("Mức trợ cấp", draft.allowance, { edit(draft.copy(allowance = it)) })
                    MoneyField(
                        label = "Thuế khấu trừ",
                        value = draft.taxDeduction,
                        onValueChange = { edit(draft.copy(taxDeduction = it)) },
                        supporting = "Số tiền cố định trừ mỗi tháng"
                    )
                    Text(
                        text = "Đơn giá giờ = (lương gốc + trợ cấp) ÷ 192 = " +
                            Fmt.money(SalaryCalculator.hourlyRate(draft)),
                        style = MaterialTheme.typography.bodySmall,
                        color = c.primary
                    )
                }
            }

            AppCard {
                SectionTitle("Vay nợ")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyField(
                        "Tiền gốc vay ban đầu",
                        draft.loanPrincipal,
                        { edit(draft.copy(loanPrincipal = it)) }
                    )
                    key(resetKey) {
                        DecimalField(
                            label = "Lãi suất vay (năm)",
                            value = draft.loanAnnualRate,
                            onValueChange = { edit(draft.copy(loanAnnualRate = it)) },
                            suffix = "%/năm",
                            supporting = "Dùng làm lãi suất mặc định khi thêm kỳ trả nợ mới"
                        )
                    }
                }
            }

            AppCard {
                SectionTitle("Giao diện")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Pill("Hệ thống", draft.themeMode == ThemeMode.SYSTEM, { edit(draft.copy(themeMode = ThemeMode.SYSTEM)) }, Modifier.weight(1f))
                    Pill("Sáng", draft.themeMode == ThemeMode.LIGHT, { edit(draft.copy(themeMode = ThemeMode.LIGHT)) }, Modifier.weight(1f))
                    Pill("Tối", draft.themeMode == ThemeMode.DARK, { edit(draft.copy(themeMode = ThemeMode.DARK)) }, Modifier.weight(1f))
                }
            }

            AppCard {
                SectionTitle("Sao lưu dữ liệu")
                Text(
                    text = "Lưu toàn bộ giờ tăng ca, cài đặt và các kỳ trả nợ ra một file. " +
                        "Dùng file này để khôi phục khi đổi điện thoại hoặc cài lại ứng dụng.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            exportLauncher.launch("otmanager-backup-${LocalDate.now()}.json")
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Sao lưu") }
                    OutlinedButton(
                        onClick = { confirmRestore = true },
                        modifier = Modifier.weight(1f)
                    ) { Text("Khôi phục") }
                }
                if (backupMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = backupMessage ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.primary
                    )
                }
            }
            // Chừa chỗ để nút Lưu không che nội dung cuối trang
            Spacer(modifier = Modifier.height(80.dp))
        }

        // Nút Lưu chỉ hiện khi có thông tin thay đổi
        if (hasChanges) {
            ExtendedFloatingActionButton(
                onClick = {
                    onChange(draft)
                    justSaved = true
                },
                containerColor = c.primary,
                contentColor = c.onPrimary,
                icon = { Icon(Icons.Rounded.Check, contentDescription = null) },
                text = { Text("Lưu thay đổi") },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
            )
        }
    }

    if (confirmRestore) {
        AlertDialog(
            onDismissRequest = { confirmRestore = false },
            containerColor = c.surface,
            title = { Text("Khôi phục dữ liệu?") },
            text = { Text("Dữ liệu hiện tại sẽ bị thay thế bằng dữ liệu trong file sao lưu.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRestore = false
                    importLauncher.launch(arrayOf("*/*"))
                }) { Text("Chọn file") }
            },
            dismissButton = {
                TextButton(onClick = { confirmRestore = false }) { Text("Hủy") }
            }
        )
    }
}
