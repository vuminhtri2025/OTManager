package com.otmanager.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// Sáng: nền xám nhạt, thẻ xám rất nhạt (không dùng trắng tinh), nhấn màu than chì.
private val LightColors = lightColorScheme(
    primary = Color(0xFF2B2E3A),
    onPrimary = Color(0xFFF4F4F6),
    primaryContainer = Color(0xFFD2D5E2),
    onPrimaryContainer = Color(0xFF1A1C28),
    secondary = Color(0xFF5C5F66),
    onSecondary = Color(0xFFF4F4F6),
    secondaryContainer = Color(0xFFD0D2D8),
    onSecondaryContainer = Color(0xFF16171A),
    tertiary = Color(0xFF4F46E5),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFE6E7EA),
    onBackground = Color(0xFF16171A),
    surface = Color(0xFFF4F4F6),
    onSurface = Color(0xFF16171A),
    surfaceVariant = Color(0xFFDADBDF),
    onSurfaceVariant = Color(0xFF5C5F66),
    outline = Color(0xFFB9BBC1),
    outlineVariant = Color(0xFFCFD1D6),
    error = Color(0xFFDC2626),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF7F1D1D),
    surfaceContainerLowest = Color(0xFFE6E7EA),
    surfaceContainerLow = Color(0xFFF4F4F6),
    surfaceContainer = Color(0xFFF4F4F6),
    surfaceContainerHigh = Color(0xFFECECEF),
    surfaceContainerHighest = Color(0xFFDADBDF)
)

// Tối: đen than + xám đậm, nhấn tím nhạt.
private val DarkColors = darkColorScheme(
    primary = Color(0xFF9AA5FF),
    onPrimary = Color(0xFF101223),
    primaryContainer = Color(0xFF2A2D3E),
    onPrimaryContainer = Color(0xFFDDE1FF),
    secondary = Color(0xFF9CA3AF),
    onSecondary = Color(0xFF111214),
    secondaryContainer = Color(0xFF2C2E33),
    onSecondaryContainer = Color(0xFFE5E7EB),
    tertiary = Color(0xFF7C83FF),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFF0B0B0D),
    onBackground = Color(0xFFECECEF),
    surface = Color(0xFF16171A),
    onSurface = Color(0xFFECECEF),
    surfaceVariant = Color(0xFF202226),
    onSurfaceVariant = Color(0xFF9A9CA3),
    outline = Color(0xFF34363B),
    outlineVariant = Color(0xFF26282C),
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A),
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFEE2E2),
    surfaceContainerLowest = Color(0xFF0B0B0D),
    surfaceContainerLow = Color(0xFF16171A),
    surfaceContainer = Color(0xFF16171A),
    surfaceContainerHigh = Color(0xFF1D1F23),
    surfaceContainerHighest = Color(0xFF202226)
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun OvertimeTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        shapes = AppShapes,
        content = content
    )
}
