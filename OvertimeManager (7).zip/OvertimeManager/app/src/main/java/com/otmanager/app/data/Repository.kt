package com.otmanager.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth

/** Lưu/đọc dữ liệu cục bộ bằng SharedPreferences (JSON), không cần thư viện ngoài. */
class Repository(context: Context) {

    private val prefs =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadSettings(): AppSettings {
        val raw = prefs.getString(KEY_SETTINGS, null) ?: return AppSettings()
        return try {
            val o = JSONObject(raw)
            val d = AppSettings()
            AppSettings(
                baseSalary = o.optLong("baseSalary", d.baseSalary),
                allowance = o.optLong("allowance", d.allowance),
                taxDeduction = o.optLong("taxDeduction", d.taxDeduction),
                loanPrincipal = o.optLong("loanPrincipal", d.loanPrincipal),
                loanAnnualRate = o.optDouble("loanAnnualRate", d.loanAnnualRate),
                themeMode = try {
                    ThemeMode.valueOf(o.optString("themeMode"))
                } catch (e: Exception) {
                    ThemeMode.SYSTEM
                }
            )
        } catch (e: Exception) {
            AppSettings()
        }
    }

    fun saveSettings(s: AppSettings) {
        val o = JSONObject()
        o.put("baseSalary", s.baseSalary)
        o.put("allowance", s.allowance)
        o.put("taxDeduction", s.taxDeduction)
        o.put("loanPrincipal", s.loanPrincipal)
        o.put("loanAnnualRate", s.loanAnnualRate)
        o.put("themeMode", s.themeMode.name)
        prefs.edit().putString(KEY_SETTINGS, o.toString()).apply()
    }

    fun loadEntries(): Map<LocalDate, DayEntry> {
        val raw = prefs.getString(KEY_ENTRIES, null) ?: return emptyMap()
        return try {
            val root = JSONObject(raw)
            val result = HashMap<LocalDate, DayEntry>()
            val keys = root.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val date = LocalDate.parse(k)
                val o = root.getJSONObject(k)
                val hours = HashMap<OtType, Double>()
                for (t in OtType.values()) {
                    val h = o.optDouble(t.key, 0.0)
                    if (h > 0.0) hours[t] = h
                }
                val entry = DayEntry(hours, o.optDouble("out", 0.0))
                if (!entry.isEmpty) result[date] = entry
            }
            result
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun saveEntries(entries: Map<LocalDate, DayEntry>) {
        val root = JSONObject()
        for ((date, entry) in entries) {
            if (entry.isEmpty) continue
            val o = JSONObject()
            for ((type, h) in entry.hours) {
                if (h > 0.0) o.put(type.key, h)
            }
            if (entry.outHours > 0.0) o.put("out", entry.outHours)
            root.put(date.toString(), o)
        }
        prefs.edit().putString(KEY_ENTRIES, root.toString()).apply()
    }

    fun loadLoanEvents(): List<LoanEvent> {
        val raw = prefs.getString(KEY_LOAN_EVENTS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                // Tương thích dữ liệu cũ: "date"/"amount" -> "month"/"principalPaid"
                val month = if (o.has("month")) {
                    YearMonth.parse(o.getString("month"))
                } else {
                    YearMonth.from(LocalDate.parse(o.getString("date")))
                }
                LoanEvent(
                    id = o.getLong("id"),
                    period = o.optInt("period", i + 1),
                    month = month,
                    principalPaid = if (o.has("principalPaid")) o.getLong("principalPaid") else o.optLong("amount", 0L),
                    annualRate = o.optDouble("annualRate", 0.0)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveLoanEvents(events: List<LoanEvent>) {
        val arr = JSONArray()
        for (e in events) {
            arr.put(
                JSONObject()
                    .put("id", e.id)
                    .put("period", e.period)
                    .put("month", e.month.toString())
                    .put("principalPaid", e.principalPaid)
                    .put("annualRate", e.annualRate)
            )
        }
        prefs.edit().putString(KEY_LOAN_EVENTS, arr.toString()).apply()
    }

    /** Xuất toàn bộ dữ liệu (cài đặt, giờ tăng ca, sự kiện trả nợ) thành một chuỗi JSON. */
    fun exportJson(): String {
        val root = JSONObject()
        root.put("app", BACKUP_APP_ID)
        root.put("version", 1)
        root.put("settings", JSONObject(prefs.getString(KEY_SETTINGS, null) ?: "{}"))
        root.put("entries", JSONObject(prefs.getString(KEY_ENTRIES, null) ?: "{}"))
        root.put("loanEvents", JSONArray(prefs.getString(KEY_LOAN_EVENTS, null) ?: "[]"))
        return root.toString(2)
    }

    /** Khôi phục từ chuỗi JSON sao lưu. Trả về false nếu file không hợp lệ (dữ liệu cũ giữ nguyên). */
    fun importJson(text: String): Boolean {
        return try {
            val root = JSONObject(text)
            if (root.optString("app") != BACKUP_APP_ID) return false
            val settings = root.getJSONObject("settings")
            val entries = root.getJSONObject("entries")
            val events = root.getJSONArray("loanEvents")
            prefs.edit()
                .putString(KEY_SETTINGS, settings.toString())
                .putString(KEY_ENTRIES, entries.toString())
                .putString(KEY_LOAN_EVENTS, events.toString())
                .apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    private companion object {
        const val BACKUP_APP_ID = "otmanager"
        const val PREFS_NAME = "ot_manager_prefs"
        const val KEY_SETTINGS = "settings"
        const val KEY_ENTRIES = "entries"
        const val KEY_LOAN_EVENTS = "loan_events"
    }
}
