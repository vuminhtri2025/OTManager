package com.otmanager.app.data

import java.time.LocalDate
import java.time.YearMonth

/** Các mức hệ số tăng ca. */
enum class OtType(val key: String, val percent: Int, val label: String, val hint: String) {
    R150("150", 150, "150%", "Ngày thường"),
    R210("210", 210, "210%", "Ngày thường – ca đêm"),
    R200("200", 200, "200%", "Ngày nghỉ hằng tuần"),
    R270("270", 270, "270%", "Ngày nghỉ – ca đêm"),
    R300("300", 300, "300%", "Ngày lễ, Tết"),
    R390("390", 390, "390%", "Ngày lễ, Tết – ca đêm");

    val multiplier: Double get() = percent / 100.0
}

/** Dữ liệu nhập cho một ngày: số giờ theo từng mức tăng ca + số giờ đi ra ngoài. */
data class DayEntry(
    val hours: Map<OtType, Double> = emptyMap(),
    val outHours: Double = 0.0
) {
    fun hoursOf(type: OtType): Double = hours[type] ?: 0.0
    val totalOt: Double get() = hours.values.sum()
    val isEmpty: Boolean get() = hours.values.all { it <= 0.0 } && outHours <= 0.0
}

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/**
 * Một kỳ trả nợ: tháng thứ mấy, tháng trả, số tiền trả gốc và lãi suất năm của kỳ đó.
 * Tiền lãi không lưu mà được tự tính từ dư nợ trước kỳ.
 */
data class LoanEvent(
    val id: Long,
    val period: Int,
    val month: YearMonth,
    val principalPaid: Long,
    val annualRate: Double
)

/** Toàn bộ cài đặt của ứng dụng. */
data class AppSettings(
    val baseSalary: Long = 0L,
    val allowance: Long = 0L,
    val taxDeduction: Long = 0L,
    val loanPrincipal: Long = 0L,
    val loanAnnualRate: Double = 0.0,
    val themeMode: ThemeMode = ThemeMode.SYSTEM
)
