package com.otmanager.app.logic

import com.otmanager.app.data.AppSettings
import com.otmanager.app.data.DayEntry
import com.otmanager.app.data.OtType
import java.time.LocalDate
import java.time.YearMonth

data class OtLine(val type: OtType, val hours: Double, val amount: Long)

data class SalaryResult(
    val hourlyRate: Double,
    val baseSalary: Long,
    val allowance: Long,
    val otLines: List<OtLine>,
    val totalOtHours: Double,
    val totalOtPay: Long,
    val outHours: Double,
    val outDeduction: Long,
    val tax: Long,
    val gross: Long,
    val totalDeduction: Long,
    val net: Long
)

/**
 * Công thức:
 *   Đơn giá giờ   = (Lương cố định + Trợ cấp) ÷ 192
 *   Lương tăng ca = Σ (số giờ × đơn giá giờ × hệ số)
 *   Trừ ra ngoài  = Số giờ ra ngoài × đơn giá giờ
 *   Thực nhận     = Lương gốc + Trợ cấp + Lương tăng ca − Trừ ra ngoài − Thuế khấu trừ
 */
object SalaryCalculator {

    /** Số giờ công chuẩn dùng tính lương giờ. */
    const val STANDARD_HOURS = 192.0

    fun hourlyRate(s: AppSettings): Double =
        (s.baseSalary + s.allowance) / STANDARD_HOURS

    fun calculate(
        month: YearMonth,
        entries: Map<LocalDate, DayEntry>,
        s: AppSettings
    ): SalaryResult {
        val hourly = hourlyRate(s)
        val hoursByType = HashMap<OtType, Double>()
        var outHours = 0.0

        for ((date, entry) in entries) {
            if (YearMonth.from(date) != month) continue
            for ((type, h) in entry.hours) {
                hoursByType[type] = (hoursByType[type] ?: 0.0) + h
            }
            outHours += entry.outHours
        }

        val lines = OtType.values().map { t ->
            val h = hoursByType[t] ?: 0.0
            OtLine(t, h, Math.round(h * hourly * t.multiplier))
        }
        val totalOtHours = lines.sumOf { it.hours }
        val totalOtPay = lines.sumOf { it.amount }
        val outDeduction = Math.round(outHours * hourly)

        val gross = s.baseSalary + s.allowance + totalOtPay
        val totalDeduction = outDeduction + s.taxDeduction
        val net = gross - totalDeduction

        return SalaryResult(
            hourlyRate = hourly,
            baseSalary = s.baseSalary,
            allowance = s.allowance,
            otLines = lines,
            totalOtHours = totalOtHours,
            totalOtPay = totalOtPay,
            outHours = outHours,
            outDeduction = outDeduction,
            tax = s.taxDeduction,
            gross = gross,
            totalDeduction = totalDeduction,
            net = net
        )
    }
}
