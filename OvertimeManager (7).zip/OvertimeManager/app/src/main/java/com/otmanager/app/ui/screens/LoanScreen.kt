package com.otmanager.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.otmanager.app.data.AppSettings
import com.otmanager.app.data.LoanEvent
import com.otmanager.app.logic.LoanCalculator
import com.otmanager.app.logic.LoanRow
import com.otmanager.app.ui.components.AppCard
import com.otmanager.app.ui.components.GradientCard
import com.otmanager.app.ui.components.ScreenTitle
import com.otmanager.app.ui.components.SectionTitle
import com.otmanager.app.util.Fmt

private val ColPeriod = 64.dp
private val ColMonth = 92.dp
private val ColPaid = 116.dp
private val ColRate = 96.dp
private val ColInterest = 104.dp
private val ColBalance = 124.dp
private val ColTotal = 124.dp

private fun pct(v: Double): String = Fmt.percent(Math.round(v * 10) / 10.0)

@Composable
fun LoanScreen(
    settings: AppSettings,
    events: List<LoanEvent>,
    onSaveEvent: (LoanEvent) -> Unit,
    onRemoveEvent: (Long) -> Unit
) {
    val summary = LoanCalculator.build(settings.loanPrincipal, events)
    val c = MaterialTheme.colorScheme
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<LoanEvent?>(null) }

    val paidPct = if (summary.principal > 0L)
        summary.paidPrincipal.toDouble() / summary.principal * 100.0 else 0.0

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            ScreenTitle("Vay nợ", "Dư nợ giảm dần theo từng kỳ trả")

            GradientCard {
                Text(
                    text = "TỔNG QUAN DƯ NỢ GIẢM DẦN",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Dư nợ còn lại",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.8f)
                )
                Text(
                    text = Fmt.money(summary.remainingDebt),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { (paidPct / 100.0).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.2f)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Đã trả gốc: ${pct(paidPct)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "Dư nợ gốc: ${pct(if (summary.principal > 0L) 100.0 - paidPct else 0.0)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp),
                    color = Color.White.copy(alpha = 0.15f)
                )
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Khoản gốc ban đầu",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                        Text(
                            Fmt.money(settings.loanPrincipal),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            "Lãi suất cài đặt",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                        Text(
                            "${Fmt.percent(settings.loanAnnualRate)}/năm",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            if (settings.loanPrincipal <= 0L) {
                AppCard {
                    Text(
                        text = "Chưa có khoản vay. Vào tab Cài đặt để nhập tiền gốc vay ban đầu và lãi suất năm.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = c.onSurfaceVariant
                    )
                }
            }

            if (summary.rows.isNotEmpty()) {
                AppCard {
                    SectionTitle("Tổng quan")
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Overview("Tổng lãi đã tính", Fmt.money(summary.totalInterest), Modifier.weight(1f))
                        Overview("Tổng đã trả (gốc + lãi)", Fmt.money(summary.totalPaid), Modifier.weight(1f))
                    }
                }
            }

            AppCard {
                SectionTitle("Lịch sử trả nợ")
                if (summary.rows.isEmpty()) {
                    Text(
                        text = "Chưa có kỳ trả nợ nào. Nhấn nút + để nhập kỳ trả: tháng thứ mấy, tháng trả, " +
                            "số tiền trả gốc và lãi suất. Tiền lãi được tự tính theo dư nợ giảm dần.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = c.onSurfaceVariant
                    )
                } else {
                    Text(
                        text = "Chạm vào một dòng để sửa hoặc xóa · vuốt ngang để xem đủ cột",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Column(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        HeaderRow()
                        summary.rows.forEach { row ->
                            DataRow(row) {
                                editing = row.event
                                showDialog = true
                            }
                        }
                    }
                }
            }
            // Chừa chỗ để nút + không che nội dung cuối trang
            Spacer(modifier = Modifier.height(72.dp))
        }

        FloatingActionButton(
            onClick = {
                editing = null
                showDialog = true
            },
            containerColor = c.primary,
            contentColor = c.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Icon(Icons.Rounded.Add, contentDescription = "Thêm kỳ trả nợ")
        }
    }

    if (showDialog) {
        val current = editing
        LoanEventDialog(
            initial = current,
            events = events,
            principal = settings.loanPrincipal,
            defaultRate = settings.loanAnnualRate,
            onDismiss = { showDialog = false },
            onSave = {
                onSaveEvent(it)
                showDialog = false
            },
            onDelete = if (current != null) {
                {
                    onRemoveEvent(current.id)
                    showDialog = false
                }
            } else null
        )
    }
}

@Composable
private fun Overview(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun HeaderRow() {
    val c = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(c.surfaceVariant)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Cell("Tháng thứ", ColPeriod, header = true, align = TextAlign.Center)
        Cell("Tháng trả nợ", ColMonth, header = true, align = TextAlign.Center)
        Cell("Tiền trả gốc", ColPaid, header = true)
        Cell("Lãi suất", ColRate, header = true)
        Cell("Tiền lãi", ColInterest, header = true)
        Cell("Dư nợ cuối kỳ", ColBalance, header = true)
        Cell("Tổng tiền trả", ColTotal, header = true)
    }
}

@Composable
private fun DataRow(row: LoanRow, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Cell("${row.event.period}", ColPeriod, align = TextAlign.Center, bold = true)
        Cell(Fmt.monthShort(row.event.month), ColMonth, align = TextAlign.Center)
        Cell(Fmt.number(row.event.principalPaid), ColPaid)
        Cell("${Fmt.percent(row.event.annualRate)}/năm", ColRate)
        Cell(Fmt.number(row.interest), ColInterest)
        Cell(Fmt.number(row.endingBalance), ColBalance)
        Cell(Fmt.number(row.totalPayment), ColTotal, bold = true)
    }
}

@Composable
private fun Cell(
    text: String,
    width: Dp,
    header: Boolean = false,
    bold: Boolean = false,
    align: TextAlign = TextAlign.End
) {
    Box(modifier = Modifier.width(width).padding(horizontal = 8.dp)) {
        Text(
            text = text,
            modifier = Modifier.fillMaxWidth(),
            textAlign = align,
            maxLines = if (header) 2 else 1,
            style = if (header) MaterialTheme.typography.labelMedium else MaterialTheme.typography.bodySmall,
            fontWeight = if (header || bold) FontWeight.Bold else FontWeight.Normal,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
