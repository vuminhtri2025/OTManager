package com.otmanager.app.ui.components

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.otmanager.app.data.OtType
import com.otmanager.app.ui.theme.otColor
import com.otmanager.app.util.Fmt
import java.time.YearMonth

/**
 * Biểu đồ cột chồng: mỗi cột là một tháng, mỗi màu là một mức tăng ca (150%, 210%...),
 * số trên nóc cột là tổng giờ OT của tháng đó, chân cột chỉ ghi số tháng (1, 2, 3...).
 * Các cột chia đều theo chiều ngang nên không cần cuộn — vuốt ngang trên biểu đồ vẫn đổi tháng.
 */
@Composable
fun OtBarChart(
    months: List<YearMonth>,
    hours: List<Map<OtType, Double>>,
    selected: YearMonth,
    onSelect: (YearMonth) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = MaterialTheme.colorScheme

    val totals = hours.map { it.values.sum() }
    val maxTotal = (totals.maxOrNull() ?: 0.0).coerceAtLeast(1.0)

    val gridColor = c.outlineVariant
    val highlight = c.primary.copy(alpha = 0.12f)
    val totalArgb = c.onSurface.toArgb()
    val labelArgb = c.onSurfaceVariant.toArgb()
    val selectedArgb = c.primary.toArgb()
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER } }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(220.dp)
            .pointerInput(months) {
                detectTapGestures { offset ->
                    val i = (offset.x / (size.width.toFloat() / months.size)).toInt()
                    if (i in months.indices) onSelect(months[i])
                }
            }
    ) {
        val topPad = 24.dp.toPx()
        val bottomPad = 26.dp.toPx()
        val plotH = size.height - topPad - bottomPad
        val slotPx = size.width / months.size
        val barW = slotPx * 0.62f
        val baseline = topPad + plotH

        for (g in 0..3) {
            val y = topPad + plotH * (1f - g / 3f)
            drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1.dp.toPx())
        }

        months.forEachIndexed { i, m ->
            val cx = slotPx * i + slotPx / 2f
            val isSel = m == selected

            if (isSel) {
                drawRoundRect(
                    color = highlight,
                    topLeft = Offset(slotPx * i + 1.dp.toPx(), 0f),
                    size = Size(slotPx - 2.dp.toPx(), size.height),
                    cornerRadius = CornerRadius(8.dp.toPx())
                )
            }

            var y = baseline
            for (t in OtType.values()) {
                val h = hours[i][t] ?: 0.0
                if (h <= 0.0) continue
                val segH = (h / maxTotal * plotH).toFloat()
                drawRect(
                    color = otColor(t),
                    topLeft = Offset(cx - barW / 2f, y - segH),
                    size = Size(barW, segH)
                )
                y -= segH
            }

            val canvas = drawContext.canvas.nativeCanvas
            if (totals[i] > 0.0) {
                paint.textSize = 10.sp.toPx()
                paint.isFakeBoldText = true
                paint.color = totalArgb
                canvas.drawText(Fmt.hours(totals[i]), cx, y - 5.dp.toPx(), paint)
            }
            // Chân cột: chỉ ghi số tháng
            paint.textSize = 12.sp.toPx()
            paint.isFakeBoldText = isSel
            paint.color = if (isSel) selectedArgb else labelArgb
            canvas.drawText("${m.monthValue}", cx, size.height - 8.dp.toPx(), paint)
        }
    }
}

/** Chú thích màu cho 6 mức tăng ca (2 hàng × 3). */
@Composable
fun OtLegend(modifier: Modifier = Modifier) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OtType.values().toList().chunked(3).forEach { row ->
            Row(modifier = Modifier.fillMaxWidth()) {
                row.forEach { t ->
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(otColor(t))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = t.label,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                }
            }
        }
    }
}
