package com.otmanager.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.otmanager.app.data.DayEntry
import com.otmanager.app.data.OtType
import com.otmanager.app.ui.theme.OutColor
import com.otmanager.app.ui.theme.otColor
import com.otmanager.app.util.Fmt
import java.time.LocalDate

private const val OUT_KEY = "out"
private const val STEP = 0.5
private const val MAX_HOURS = 24.0

/** Hộp thoại nhập số giờ tăng ca (6 mức) và giờ ra ngoài cho một ngày. */
@Composable
fun DayEditorDialog(
    date: LocalDate,
    initial: DayEntry,
    onDismiss: () -> Unit,
    onSave: (DayEntry) -> Unit
) {
    val c = MaterialTheme.colorScheme
    val texts = remember(date) {
        mutableStateMapOf<String, String>().apply {
            for (t in OtType.values()) put(t.key, Fmt.plain(initial.hoursOf(t)))
            put(OUT_KEY, Fmt.plain(initial.outHours))
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(28.dp),
            color = c.surface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = Fmt.dayLabel(date),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = c.onSurface
                )
                Text(
                    text = "Nhập số giờ cho từng mức (bước 0,5 giờ)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    for (t in OtType.values()) {
                        HourRow(
                            label = t.label,
                            hint = t.hint,
                            color = otColor(t),
                            text = texts[t.key] ?: "",
                            onChange = { texts[t.key] = it }
                        )
                    }
                    HorizontalDivider(color = c.outlineVariant)
                    HourRow(
                        label = "Ra ngoài",
                        hint = "Trừ vào lương theo đơn giá giờ",
                        color = OutColor,
                        text = texts[OUT_KEY] ?: "",
                        onChange = { texts[OUT_KEY] = it }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!initial.isEmpty) {
                        TextButton(onClick = { onSave(DayEntry()) }) {
                            Text("Xóa", color = c.error)
                        }
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("Hủy") }
                    Button(
                        onClick = {
                            val hours = HashMap<OtType, Double>()
                            for (t in OtType.values()) {
                                val h = (Fmt.parseDecimal(texts[t.key] ?: "") ?: 0.0)
                                    .coerceIn(0.0, MAX_HOURS)
                                if (h > 0.0) hours[t] = h
                            }
                            val out = (Fmt.parseDecimal(texts[OUT_KEY] ?: "") ?: 0.0)
                                .coerceIn(0.0, MAX_HOURS)
                            onSave(DayEntry(hours, out))
                        }
                    ) { Text("Lưu") }
                }
            }
        }
    }
}

@Composable
private fun HourRow(
    label: String,
    hint: String,
    color: Color,
    text: String,
    onChange: (String) -> Unit
) {
    val c = MaterialTheme.colorScheme
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                color = c.onSurface
            )
            Text(
                text = hint,
                style = MaterialTheme.typography.bodySmall,
                color = c.onSurfaceVariant
            )
        }
        StepButton(Icons.Rounded.Remove, "Giảm") { onChange(stepText(text, -STEP)) }
        Spacer(modifier = Modifier.width(4.dp))
        HourField(value = text, onChange = onChange)
        Spacer(modifier = Modifier.width(4.dp))
        StepButton(Icons.Rounded.Add, "Tăng") { onChange(stepText(text, STEP)) }
    }
}

private fun stepText(text: String, delta: Double): String {
    val current = Fmt.parseDecimal(text) ?: 0.0
    return Fmt.plain((current + delta).coerceIn(0.0, MAX_HOURS))
}

@Composable
private fun StepButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(c.primaryContainer)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = c.onPrimaryContainer,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun HourField(value: String, onChange: (String) -> Unit) {
    val c = MaterialTheme.colorScheme
    BasicTextField(
        value = value,
        onValueChange = { raw ->
            val cleaned = raw.replace(',', '.').filter { it.isDigit() || it == '.' }
            if (cleaned.count { it == '.' } <= 1 && cleaned.length <= 5) onChange(cleaned)
        },
        singleLine = true,
        textStyle = TextStyle(
            color = c.onSurface,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        ),
        cursorBrush = SolidColor(c.primary),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        decorationBox = { inner ->
            Box(
                modifier = Modifier
                    .width(64.dp)
                    .height(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(c.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (value.isEmpty()) {
                    Text(
                        text = "0",
                        color = c.onSurfaceVariant.copy(alpha = 0.6f),
                        fontSize = 16.sp
                    )
                }
                inner()
            }
        }
    )
}
