package com.otmanager.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.RemoteViews
import com.otmanager.app.MainActivity
import com.otmanager.app.R
import com.otmanager.app.data.Repository
import com.otmanager.app.logic.OtStats
import com.otmanager.app.util.Fmt
import java.time.YearMonth

/**
 * Widget màn hình chính: tổng giờ tăng ca tháng này + biểu đồ giờ OT 12 tháng.
 * Có thể kéo to/nhỏ; biểu đồ được vẽ lại vừa khít theo kích thước hiện tại.
 */
class OtWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (id in appWidgetIds) updateOne(context, appWidgetManager, id)
    }

    // Người dùng kéo đổi kích thước widget -> vẽ lại theo kích thước mới
    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        updateOne(context, appWidgetManager, appWidgetId)
    }

    companion object {
        private const val DEFAULT_W_DP = 250
        private const val DEFAULT_H_DP = 160
        private const val PADDING_DP = 14f
        private const val HEADER_DP = 34f
        private const val GAP_DP = 6f
        private const val MIN_CHART_H_DP = 36f
        private const val MAX_BITMAP_W = 1000f
        private const val MAX_BITMAP_H = 600f

        /** Gọi sau khi dữ liệu thay đổi để mọi widget cập nhật ngay. */
        fun refresh(context: Context) {
            val ctx = context.applicationContext
            val manager = AppWidgetManager.getInstance(ctx)
            val ids = manager.getAppWidgetIds(ComponentName(ctx, OtWidgetProvider::class.java))
            for (id in ids) updateOne(ctx, manager, id)
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val options = manager.getAppWidgetOptions(id)
            val widthDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
                .takeIf { it > 0 } ?: DEFAULT_W_DP
            val heightDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
                .takeIf { it > 0 } ?: DEFAULT_H_DP
            manager.updateAppWidget(id, buildViews(context, widthDp, heightDp))
        }

        private fun buildViews(context: Context, widthDp: Int, heightDp: Int): RemoteViews {
            val month = YearMonth.now()
            val entries = Repository(context).loadEntries()
            val monthEntries = entries.filter { YearMonth.from(it.key) == month }
            val totalOt = monthEntries.values.sumOf { it.totalOt }
            val totalOut = monthEntries.values.sumOf { it.outHours }

            val views = RemoteViews(context.packageName, R.layout.widget_ot)
            views.setTextViewText(
                R.id.widget_title,
                "Tăng ca ${month.monthValue}/${month.year}" +
                    if (totalOut > 0.0) " · ra ngoài ${Fmt.hours(totalOut)}h" else ""
            )
            views.setTextViewText(R.id.widget_hours, "${Fmt.hours(totalOt)} giờ")

            // Khung biểu đồ = kích thước widget trừ lề và dòng tiêu đề
            val chartW = (widthDp - 2 * PADDING_DP).coerceAtLeast(40f)
            val chartH = heightDp - 2 * PADDING_DP - HEADER_DP - GAP_DP
            if (chartH < MIN_CHART_H_DP) {
                // Widget quá thấp: chỉ hiện số giờ, ẩn biểu đồ
                views.setViewVisibility(R.id.widget_chart, View.GONE)
            } else {
                val density = context.resources.displayMetrics.density
                val scale = minOf(1f, MAX_BITMAP_W / (chartW * density), MAX_BITMAP_H / (chartH * density))
                val chartMonths = OtStats.lastMonths(month)
                val chartData = OtStats.hoursByMonth(entries, chartMonths)
                views.setViewVisibility(R.id.widget_chart, View.VISIBLE)
                views.setImageViewBitmap(
                    R.id.widget_chart,
                    WidgetChart.render(chartMonths, chartData, month, chartW, chartH, density * scale)
                )
            }

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pending = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            return views
        }
    }
}
