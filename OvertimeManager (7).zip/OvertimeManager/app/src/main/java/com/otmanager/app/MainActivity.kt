package com.otmanager.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import com.otmanager.app.data.ThemeMode
import com.otmanager.app.ui.screens.LoanScreen
import com.otmanager.app.ui.screens.OvertimeScreen
import com.otmanager.app.ui.screens.SettingsScreen
import com.otmanager.app.ui.theme.OvertimeTheme
import com.otmanager.app.viewmodel.MainViewModel

private data class TabItem(val title: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem("Overtime", Icons.Rounded.CalendarMonth),
    TabItem("Vay nợ", Icons.Rounded.AccountBalance),
    TabItem("Cài đặt", Icons.Rounded.Settings)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
private fun App(vm: MainViewModel = viewModel()) {
    val dark = when (vm.settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    OvertimeTheme(darkTheme = dark) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    tabs.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(t.icon, contentDescription = t.title) },
                            label = { Text(t.title) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .statusBarsPadding()
            ) {
                when (tab) {
                    0 -> OvertimeScreen(
                        month = vm.selectedMonth,
                        entries = vm.entries,
                        settings = vm.settings,
                        onMonthChange = vm::selectMonth,
                        onSaveEntry = vm::saveEntry
                    )
                    1 -> LoanScreen(
                        settings = vm.settings,
                        events = vm.loanEvents,
                        onSaveEvent = vm::saveLoanEvent,
                        onRemoveEvent = vm::removeLoanEvent
                    )
                    else -> SettingsScreen(
                        settings = vm.settings,
                        onChange = vm::updateSettings,
                        exportData = vm::exportBackup,
                        importData = vm::importBackup
                    )
                }
            }
        }
    }
}
