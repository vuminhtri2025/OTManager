package com.otmanager.app.ui.theme

import androidx.compose.ui.graphics.Color
import com.otmanager.app.data.OtType

val OutColor = Color(0xFFEC4899)

/** Màu nhận diện cho từng mức tăng ca (dùng trên lịch và bảng chú thích). */
fun otColor(type: OtType): Color = when (type) {
    OtType.R150 -> Color(0xFF3B82F6)
    OtType.R210 -> Color(0xFF6366F1)
    OtType.R200 -> Color(0xFF10B981)
    OtType.R270 -> Color(0xFF06B6D4)
    OtType.R300 -> Color(0xFFF59E0B)
    OtType.R390 -> Color(0xFFEF4444)
}
