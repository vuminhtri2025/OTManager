package com.otmanager.app.widget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.ui.graphics.toArgb
import com.otmanager.app.data.OtType
import com.otmanager.app.ui.theme.otColor
import com.otmanager.app.util.Fmt
import java.time.YearMonth

/**
 * Vẽ biểu đồ cột chồng giờ OT 12 tháng thành ảnh để đưa vào widget
 * (widget không vẽ trực tiếp được nên dùng bitmap). Nền trong suốt, chữ sáng.
 * Kích thước ảnh theo đúng khung biểu đồ của widget nên kéo to/nhỏ widget thì biểu đồ co giãn theo.
 */
object WidgetChart {

    /**
     * @param widthDp  chiều rộng khung biểu đồ (dp)
     * @param heightDp chiều cao khung biểu đồ (dp)
     * @param pxPerDp  số pixel trên mỗi dp (đã gồm hệ số thu nhỏ nếu ảnh quá lớn)
     */
    fun render(
        months: List<YearMonth>,
        hours: List<Map<OtType, Double>>,
        current: YearMonth,
        widthDp: Float,
        heightDp: Float,
        pxPerDp: Float
    ): Bitmap {
        val w = (widthDp * pxPerDp).toInt().coerceAtLeast(1)
        val h = (heightDp * pxPerDp).toInt().coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val totals = hours.map { it.values.sum() }
        val maxTotal = (totals.maxOrNull() ?: 0.0).coerceAtLeast(1.0)

        val slot = w / months.size.toFloat()
        val slotDp = slot / pxPerDp
        // Widget hẹp thì bớt chữ cho khỏi chồng lên nhau
        val showTotals = slotDp >= 18f
        val labelStep = if (slotDp >= 14f) 1 else 2

        val topPad = (if (showTotals) 14f else 4f) * pxPerDp
        val bottomPad = 16f * pxPerDp
        val plotH = (h - topPad - bottomPad).coerceAtLeast(1f)
        val baseline = topPad + plotH
        val barW = slot * 0.62f

        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x33FFFFFF
            strokeWidth = pxPerDp
        }
        for (g in 0..3) {
            val y = topPad + plotH * (1f - g / 3f)
            canvas.drawLine(0f, y, w.toFloat(), y, gridPaint)
        }

        val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        val totalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt()
            textSize = 10f * pxPerDp
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 11f * pxPerDp
            textAlign = Paint.Align.CENTER
        }

        months.forEachIndexed { i, m ->
            val cx = slot * i + slot / 2f
            var y = baseline
            for (t in OtType.values()) {
                val hr = hours[i][t] ?: 0.0
                if (hr <= 0.0) continue
                val segH = (hr / maxTotal * plotH).toFloat()
                barPaint.color = otColor(t).toArgb()
                canvas.drawRect(RectF(cx - barW / 2f, y - segH, cx + barW / 2f, y), barPaint)
                y -= segH
            }
            if (showTotals && totals[i] > 0.0) {
                canvas.drawText(Fmt.hours(totals[i]), cx, y - 3f * pxPerDp, totalPaint)
            }
            // Chân cột chỉ ghi số tháng (widget hẹp thì ghi cách một tháng)
            val isCurrent = m == current
            if (labelStep == 1 || isCurrent || i % 2 == months.size % 2) {
                labelPaint.color = if (isCurrent) 0xFF9AA5FF.toInt() else 0xFF9A9CA3.toInt()
                labelPaint.isFakeBoldText = isCurrent
                canvas.drawText("${m.monthValue}", cx, h - 3f * pxPerDp, labelPaint)
            }
        }
        return bitmap
    }
}
