package com.otmanager.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.otmanager.app.data.LoanEvent
import com.otmanager.app.logic.LoanCalculator
import com.otmanager.app.ui.components.DecimalField
import com.otmanager.app.ui.components.MoneyField
import com.otmanager.app.ui.components.MonthPickerDialog
import com.otmanager.app.ui.theme.OutColor
import com.otmanager.app.util.Fmt
import java.time.YearMonth

/**
 * Nhập / sửa một kỳ trả nợ: tháng thứ mấy, thời gian trả (tháng), số tiền trả gốc, lãi suất năm.
 * Tiền lãi tự tính = dư nợ gốc trước kỳ × lãi suất năm ÷ 12.
 */
@Composable
fun LoanEventDialog(
    initial: LoanEvent?,
    events: List<LoanEvent>,
    principal: Long,
    defaultRate: Double,
    onDismiss: () -> Unit,
    onSave: (LoanEvent) -> Unit,
    onDelete: (() -> Unit)? = null
) {
    val c = MaterialTheme.colorScheme
    val nextPeriod = (events.maxOfOrNull { it.period } ?: 0) + 1
    val defaultMonth = events.maxByOrNull { it.month }?.month?.plusMonths(1) ?: YearMonth.now()

    var periodText by remember { mutableStateOf((initial?.period ?: nextPeriod).toString()) }
    var month by remember { mutableStateOf(initial?.month ?: defaultMonth) }
    var paid by remember { mutableStateOf(initial?.principalPaid ?: 0L) }
    var rate by remember { mutableStateOf(initial?.annualRate ?: defaultRate) }
    var showMonthPicker by remember { mutableStateOf(false) }

    val period = periodText.toIntOrNull() ?: 0
    val before = LoanCalculator.balanceBefore(principal, events, month, period, initial?.id ?: -1L)
    val interest = LoanCalculator.interestOf(before, rate)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surface,
        title = {
            Text(
                if (initial == null) "Nhập kỳ trả nợ" else "Sửa kỳ trả nợ",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = periodText,
                        onValueChange = { raw -> periodText = raw.filter { it.isDigit() }.take(4) },
                        label = { Text("Tháng thứ mấy") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.weight(1f)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { showMonthPicker = true },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                        ) {
                            Text("Tháng %02d/%d".format(month.monthValue, month.year))
                        }
                    }
                }

                MoneyField(
                    label = "Số tiền trả gốc",
                    value = paid,
                    onValueChange = { paid = it }
                )

                DecimalField(
                    label = "Lãi suất năm",
                    value = rate,
                    onValueChange = { rate = it },
                    suffix = "%"
                )

                // Tiền lãi tự tính (chỉ đọc)
                Column {
                    Text(
                        text = "Số tiền trả lãi tự tính",
                        style = MaterialTheme.typography.labelMedium,
                        color = c.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(c.surfaceVariant)
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = Fmt.money(interest),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = OutColor
                        )
                    }
                    Text(
                        text = "Dư nợ gốc trước kỳ: ${Fmt.money(before)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Text(
                        text = "Tổng tiền cần trả: ${Fmt.money(paid + interest)}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = c.onSurface,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text("Xóa kỳ này", color = c.error)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        LoanEvent(
                            id = initial?.id ?: System.currentTimeMillis(),
                            period = period,
                            month = month,
                            principalPaid = paid,
                            annualRate = rate
                        )
                    )
                },
                enabled = paid > 0L && period > 0
            ) { Text("Lưu kỳ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )

    if (showMonthPicker) {
        MonthPickerDialog(
            initial = month,
            onSelected = {
                month = it
                showMonthPicker = false
            },
            onDismiss = { showMonthPicker = false }
        )
    }
}
