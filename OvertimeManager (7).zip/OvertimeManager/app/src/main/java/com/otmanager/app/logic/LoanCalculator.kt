package com.otmanager.app.logic

import com.otmanager.app.data.LoanEvent
import java.time.YearMonth

data class LoanRow(
    val event: LoanEvent,
    val balanceBefore: Long,   // Dư nợ gốc trước kỳ
    val interest: Long,        // Tiền lãi = dư nợ trước kỳ × lãi suất năm ÷ 12
    val endingBalance: Long,   // Dư nợ cuối kỳ = dư nợ trước kỳ − gốc đã trả
    val totalPayment: Long     // Tổng tiền trả = gốc + lãi
)

data class LoanSummary(
    val rows: List<LoanRow>,
    val principal: Long,
    val remainingDebt: Long,
    val paidPrincipal: Long,
    val totalInterest: Long,
    val totalPaid: Long
)

/**
 * Dư nợ giảm dần:
 *   Dư nợ trước kỳ  = Gốc ban đầu − tổng gốc đã trả ở các kỳ trước
 *   Tiền lãi kỳ     = Dư nợ trước kỳ × Lãi suất năm ÷ 12
 *   Tổng tiền trả   = Gốc trả trong kỳ + Tiền lãi
 * Các kỳ được xếp theo (tháng trả, tháng thứ mấy).
 */
object LoanCalculator {

    fun interestOf(balance: Long, annualRate: Double): Long =
        Math.round(balance * annualRate / 12.0 / 100.0)

    fun sorted(events: List<LoanEvent>): List<LoanEvent> =
        events.sortedWith(compareBy({ it.month }, { it.period }, { it.id }))

    /** Dư nợ gốc ngay trước một kỳ (tháng, số thứ tự) — dùng khi nhập kỳ mới hoặc sửa kỳ. */
    fun balanceBefore(
        principal: Long,
        events: List<LoanEvent>,
        month: YearMonth,
        period: Int,
        excludeId: Long = -1L
    ): Long {
        val paidBefore = events
            .filter { it.id != excludeId }
            .filter { it.month.isBefore(month) || (it.month == month && it.period < period) }
            .sumOf { it.principalPaid }
        return (principal - paidBefore).coerceAtLeast(0L)
    }

    fun build(principal: Long, events: List<LoanEvent>): LoanSummary {
        var balance = principal.coerceAtLeast(0L)
        val rows = ArrayList<LoanRow>()
        for (e in sorted(events)) {
            val interest = interestOf(balance, e.annualRate)
            val ending = (balance - e.principalPaid).coerceAtLeast(0L)
            rows.add(LoanRow(e, balance, interest, ending, e.principalPaid + interest))
            balance = ending
        }
        return LoanSummary(
            rows = rows,
            principal = principal,
            remainingDebt = balance,
            paidPrincipal = (principal - balance).coerceAtLeast(0L),
            totalInterest = rows.sumOf { it.interest },
            totalPaid = rows.sumOf { it.totalPayment }
        )
    }
}
