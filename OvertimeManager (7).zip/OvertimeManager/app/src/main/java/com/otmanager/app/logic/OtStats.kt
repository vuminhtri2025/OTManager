package com.otmanager.app.logic

import com.otmanager.app.data.DayEntry
import com.otmanager.app.data.OtType
import java.time.LocalDate
import java.time.YearMonth

/** Thống kê giờ tăng ca theo tháng (dùng cho biểu đồ trong app và widget). */
object OtStats {
    const val CHART_MONTHS = 12

    /** 12 tháng cố định: từ 11 tháng trước đến tháng hiện tại. */
    fun lastMonths(now: YearMonth = YearMonth.now()): List<YearMonth> =
        (CHART_MONTHS - 1 downTo 0).map { now.minusMonths(it.toLong()) }

    /** Số giờ theo từng mức (150%, 210%...) cho mỗi tháng trong danh sách. */
    fun hoursByMonth(
        entries: Map<LocalDate, DayEntry>,
        months: List<YearMonth>
    ): List<Map<OtType, Double>> {
        val index = HashMap<YearMonth, Int>()
        months.forEachIndexed { i, m -> index[m] = i }
        val result = months.map { HashMap<OtType, Double>() }
        for ((date, entry) in entries) {
            val i = index[YearMonth.from(date)] ?: continue
            for ((type, h) in entry.hours) {
                result[i][type] = (result[i][type] ?: 0.0) + h
            }
        }
        return result
    }
}
