package com.otmanager.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.otmanager.app.data.AppSettings
import com.otmanager.app.data.DayEntry
import com.otmanager.app.data.OtType
import com.otmanager.app.ui.components.AppCard
import com.otmanager.app.ui.components.MonthNavigator
import com.otmanager.app.ui.components.ScreenTitle
import com.otmanager.app.ui.components.SectionTitle
import com.otmanager.app.ui.theme.OutColor
import com.otmanager.app.ui.theme.otColor
import com.otmanager.app.util.Fmt
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

// Mỗi tháng là một trang. Phạm vi trang: 01/2015 -> 12/2054.
private val PAGER_BASE: YearMonth = YearMonth.of(2015, 1)
private const val PAGER_COUNT = 12 * 40

private fun pageOf(m: YearMonth): Int =
    ((m.year - PAGER_BASE.year) * 12 + m.monthValue - PAGER_BASE.monthValue)
        .coerceIn(0, PAGER_COUNT - 1)

private fun monthOf(page: Int): YearMonth = PAGER_BASE.plusMonths(page.toLong())

/**
 * Trang Overtime: lịch tháng (nhập giờ) ở trên, thống kê lương + biểu đồ ở dưới.
 * Giữ và kéo trái/phải ở bất kỳ đâu trên trang để lật sang tháng trước/sau:
 * trang bám theo ngón tay, thấy cả hai tháng trượt qua nhau, thả tay thì tự khớp về trang gần nhất.
 */
@Composable
fun OvertimeScreen(
    month: YearMonth,
    entries: Map<LocalDate, DayEntry>,
    settings: AppSettings,
    onMonthChange: (YearMonth) -> Unit,
    onSaveEntry: (LocalDate, DayEntry) -> Unit
) {
    val pagerState = rememberPagerState(initialPage = pageOf(month)) { PAGER_COUNT }
    // Dùng chung một vị trí cuộn dọc cho mọi trang: trang mới hiện ra đúng vị trí trang cũ
    val scrollState = rememberScrollState()
    val currentMonth by rememberUpdatedState(month)
    val onChange by rememberUpdatedState(onMonthChange)

    // Tháng đổi từ nơi khác (nút ‹ ›, chọn tháng, chạm cột biểu đồ) -> trang trượt tới tháng đó
    LaunchedEffect(month) {
        val target = pageOf(month)
        if (pagerState.currentPage != target) pagerState.animateScrollToPage(target)
    }
    // Kéo xong và trang đã dừng -> cập nhật tháng đang chọn
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.settledPage }.collect { page ->
            val m = monthOf(page)
            if (m != currentMonth) onChange(m)
        }
    }

    HorizontalPager(
        state = pagerState,
        modifier = Modifier.fillMaxSize(),
        key = { it }
    ) { page ->
        OvertimePage(
            month = monthOf(page),
            entries = entries,
            settings = settings,
            scrollState = scrollState,
            onMonthChange = onMonthChange,
            onSaveEntry = onSaveEntry
        )
    }
}

@Composable
private fun OvertimePage(
    month: YearMonth,
    entries: Map<LocalDate, DayEntry>,
    settings: AppSettings,
    scrollState: ScrollState,
    onMonthChange: (YearMonth) -> Unit,
    onSaveEntry: (LocalDate, DayEntry) -> Unit
) {
    var selected by remember { mutableStateOf<LocalDate?>(null) }

    val monthEntries = entries.filter { YearMonth.from(it.key) == month }
    val hoursByType = OtType.values().associateWith { t ->
        monthEntries.values.sumOf { it.hoursOf(t) }
    }
    val totalOt = hoursByType.values.sum()
    val totalOut = monthEntries.values.sumOf { it.outHours }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("Overtime", "Chạm vào ngày để nhập giờ · giữ và kéo trái/phải để đổi tháng")
        MonthNavigator(month = month, onChange = onMonthChange)

        AppCard {
            MonthGrid(
                month = month,
                entries = entries,
                onDayClick = { selected = it }
            )
        }

        AppCard {
            SectionTitle("Tổng kết ${Fmt.monthTitle(month).lowercase()}")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SummaryStat("Tổng tăng ca", "${Fmt.hours(totalOt)} giờ", MaterialTheme.colorScheme.primary)
                SummaryStat("Ra ngoài", "${Fmt.hours(totalOut)} giờ", OutColor)
            }
            Spacer(modifier = Modifier.height(12.dp))
            for (t in OtType.values()) {
                val h = hoursByType[t] ?: 0.0
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(otColor(t))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "${t.label} · ${t.hint}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "${Fmt.hours(h)} giờ",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (h > 0) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Thống kê nằm ngay dưới lịch
        StatsSection(
            month = month,
            entries = entries,
            settings = settings,
            onMonthChange = onMonthChange
        )
        Spacer(modifier = Modifier.height(8.dp))
    }

    selected?.let { date ->
        DayEditorDialog(
            date = date,
            initial = entries[date] ?: DayEntry(),
            onDismiss = { selected = null },
            onSave = {
                onSaveEntry(date, it)
                selected = null
            }
        )
    }
}

@Composable
private fun SummaryStat(label: String, value: String, color: Color) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
private fun MonthGrid(
    month: YearMonth,
    entries: Map<LocalDate, DayEntry>,
    onDayClick: (LocalDate) -> Unit
) {
    val c = MaterialTheme.colorScheme
    val today = LocalDate.now()
    // Cột đầu tiên là Chủ nhật (CN = 0, T2 = 1, ... T7 = 6)
    val firstOffset = month.atDay(1).dayOfWeek.value % 7
    val days = month.lengthOfMonth()
    // Luôn vẽ đủ 6 hàng (tháng ít ngày thì hàng thừa để trống) để mọi tháng cao bằng nhau,
    // khi kéo sang tháng khác các trang không bị lệch
    val weeks = 6
    val weekdays = listOf(
        DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
        DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY
    )

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(modifier = Modifier.fillMaxWidth()) {
            for (d in weekdays) {
                Text(
                    text = Fmt.weekdayShort(d),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (d == DayOfWeek.SUNDAY) c.error else c.onSurfaceVariant
                )
            }
        }
        for (w in 0 until weeks) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (col in 0 until 7) {
                    val dayNum = w * 7 + col - firstOffset + 1
                    Box(modifier = Modifier.weight(1f)) {
                        if (dayNum in 1..days) {
                            val date = month.atDay(dayNum)
                            DayCell(
                                date = date,
                                entry = entries[date],
                                isToday = date == today,
                                onClick = { onDayClick(date) }
                            )
                        } else {
                            Spacer(modifier = Modifier.aspectRatio(CELL_RATIO))
                        }
                    }
                }
            }
        }
    }
}

private const val CELL_RATIO = 0.68f

@Composable
private fun DayCell(
    date: LocalDate,
    entry: DayEntry?,
    isToday: Boolean,
    onClick: () -> Unit
) {
    val c = MaterialTheme.colorScheme
    val hasData = entry != null && !entry.isEmpty
    val isSunday = date.dayOfWeek == DayOfWeek.SUNDAY
    val shape = RoundedCornerShape(14.dp)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(CELL_RATIO)
            .clip(shape)
            .background(
                if (hasData) c.primaryContainer.copy(alpha = 0.7f)
                else c.surfaceVariant.copy(alpha = 0.5f)
            )
            .then(
                if (isToday) Modifier.border(BorderStroke(2.dp, c.primary), shape)
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(top = 6.dp, bottom = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = "${date.dayOfMonth}",
            fontSize = 14.sp,
            fontWeight = if (isToday) FontWeight.ExtraBold else FontWeight.SemiBold,
            color = when {
                isToday -> c.primary
                isSunday -> c.error
                else -> c.onSurface
            }
        )

        if (hasData && entry != null) {
            // Tổng số giờ tăng ca trong ngày
            if (entry.totalOt > 0.0) {
                Text(
                    text = "${Fmt.hours(entry.totalOt)}h",
                    fontSize = 13.sp,
                    maxLines = 1,
                    fontWeight = FontWeight.ExtraBold,
                    color = c.onPrimaryContainer
                )
            }
            // Chấm màu theo các mức đã nhập
            val types = OtType.values().filter { entry.hoursOf(it) > 0.0 }
            if (types.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (t in types.take(4)) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(otColor(t))
                        )
                    }
                }
            }
            if (entry.outHours > 0.0) {
                Text(
                    text = "-${Fmt.hours(entry.outHours)}h",
                    fontSize = 10.sp,
                    maxLines = 1,
                    fontWeight = FontWeight.Bold,
                    color = OutColor
                )
            }
        }
    }
}
